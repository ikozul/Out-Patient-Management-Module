import DALLibrary.DateTimeConverter;
import Models.MiniReport;
import Repo.RepoFactory;

import javax.swing.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class main {
    public static void main(String[] args) {
        setLookAndFeelForForms();
        Repo.Repo repo = (Repo.Repo)RepoFactory.getRepository();
        //testRepo();
        SwingUtilities.invokeLater(() -> {
            final Home home = new Home();
        });
    }

    private static void setLookAndFeelForForms() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // If Nimbus is not available, fall back to cross-platform
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception ex) {
                // not worth my time
            }
        }
    }

    private static void testRepo(){
        Repo.Repo repo = (Repo.Repo)RepoFactory.getRepository();

        MiniReport miniReport = repo.GetMiniReportByID(3);
        miniReport.setContactPhone1("REVISED");
        miniReport.setDoctorID(2);
        miniReport.setSectionID(2);
        repo.EditMiniReport(miniReport);

        System.out.println(miniReport);

        miniReport.setFullName("INSERTED");
        repo.InsertMiniReport(miniReport);

        List<MiniReport> list = repo.GetAllMiniReports();
        for (MiniReport mr:list) {
            System.out.println(mr);
        }

       // repo.DeleteMiniReport(1);

        list = repo.GetAllMiniReports();
        for (MiniReport mr:list) {
            System.out.println(mr);
        }
    }
}
