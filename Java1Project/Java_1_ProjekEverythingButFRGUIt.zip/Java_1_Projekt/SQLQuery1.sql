use Java_1_DB
EXEC [dbo].[usp_MiniRegistrationFormsSelect] 1
EXEC usp_MiniRegistrationFormsInsert 'Marko Marulja', '23.02.1996','Umirem','01 4588 452','098 555 6445','Marijana Maric','sestra','22.02.2018'